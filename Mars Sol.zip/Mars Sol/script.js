
$('#getbtn').click(function(event){
    event.preventDefault();
    var sol=$('#sol').val();
    var page=$('#page').val();
    
    if( sol=== "" ||page==="") {
        alert("Please fill the field");
        return;
    }
    let url = "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?sol=" + sol + "&page=" + page + "&api_key=DEMO_KEY";
    $.get(url, function (data) {
        let photos = data.photos;
        
        if(photos.length === 0 ) {
            alert("No photos available for this date");
            return;
        }
        
        $("#sec img").remove();

        for (let photo of photos) {
            $('#sec').append('<img src="' + photo.img_src + '" alt="' + photo.id + '">');
        }
    });
    
    
});