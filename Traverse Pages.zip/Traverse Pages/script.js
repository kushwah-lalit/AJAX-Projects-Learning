$('#pre').attr('disabled','true');
$('#nxt').attr('disabled','true');
var page = 1;
$('#getbtn').click(function(event){
    event.preventDefault();
    show(page);
    $('#nxt').removeAttr('disabled');
});
function show(page){
    var sol=$('#sol').val();
    if(sol=== "") {
        alert("Please fill the field");
        return;
    }
   let url = "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?sol=" + sol + "&page=" + page + "&api_key=NBlCLhD21Eud5RxMy1TjZoeJedDa1c1qbsnLMIG2";
    $.get(url, function (data) {
        let photos = data.photos;
        
        if(photos.length === 0 ) {
            $('#nxt').attr('disabled','true');
            $('#pre').removeAttr('disabled');
            alert("No more images to show...");
            return;
        }
        
        $("#sec img").remove();

        for (let photo of photos) {
            $('#sec').append('<img src="' + photo.img_src + '" alt="' + photo.id + '">');
        }
    }).fail(function(){
        console.log("fail");
    });
}
$('#nxt').click(function(event){
    event.preventDefault();
    show(++page);
    if(page===2){
        $('#pre').removeAttr('disabled');
    }
});
$('#pre').click(function(event){
    event.preventDefault();
    show(--page);
    if(page===1){
        $('#nxt').removeAttr('disabled');
        $('#pre').attr('disabled','true');
    }
});