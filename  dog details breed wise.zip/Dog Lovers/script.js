var imagebtn=$('#getbtn');
var listop=$('#list');
var img=$('#imgbox');
var nextbtn=$('#nxt');
var Breed;
var toavoid=true;
//since asynchornous so this is the first thing we have to do when page loads...to get the list items
$.get("https://dog.ceo/api/breeds/list/all", function (data) {
    let dogBreeds = data.message;
    for (let breed in dogBreeds) {
        listop.append('<option value="' + breed + '">' + breed + '</option>');
    }
});
listop.change(function () {
    toavoid = true;
});
$('#getbtn').click(function(event){
    event.preventDefault();
    if(toavoid==true){
        Breed=listop.val();
        show(Breed);
        toavoid=false;
    }
});
$('#nxt').click(function(event){
    event.preventDefault();
    if(Breed!==undefined){
        show(Breed);
        toavoid=false;
    }
});
function show(Breed){
    $("#imgbox img").remove();
    let url = "https://dog.ceo/api/breed/" + Breed + "/images/random";

$.get(url, function (data) {
    let imgUrl = data.message;
    $('#imgbox').append('<img src="' + imgUrl + '" alt="' + Breed + '">');
 
});
}
// var breedImage = $("#imgbox");
// var dropdown = $("#list");
// var allowSubmit = true;
// var breed;

// $.get("https://dog.ceo/api/breeds/list/all", function (data, status) {
//     let dogBreeds = data.message;
//     for (let breed in dogBreeds) {
//         dropdown.append('<option value="' + breed + '">' + breed + '</option>');
//     }
// });

// dropdown.change(function () {
//     allowSubmit = true;
// });

// $("#getbtn").click(function (e) {
//     e.preventDefault();

//     if (allowSubmit) {
//         breed = dropdown.val();
//         displayDog(breed);
//         allowSubmit = false;
//     }

// });

// $("#nxt").click(function (e) {
//     e.preventDefault();
//     if (breed !== undefined) {
//         displayDog(breed);
//     }
// });

// function displayDog(breed) {
//     let url = "https://dog.ceo/api/breed/" + breed + "/images/random";

//     $("#imgbox img").remove();

//     $.get(url, function (data, status) {
//         let imageUrl = data.message;
//         breedImage.append('<img src="' + imageUrl + '" alt="' + breed + '">');
//     });

// }
