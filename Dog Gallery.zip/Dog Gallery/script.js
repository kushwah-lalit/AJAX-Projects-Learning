var imagebtn=$('#getbtn');
var listop=$('#list');
var img=$('#imgbox');
var nextbtn=$('#nxt');
var Breed,subbreed;
//since asynchornous so this is the first thing we have to do when page loads...to get the list items
$.get("https://dog.ceo/api/breeds/list/all", function (data) {
    let dogBreeds = data.message;
    for (let breed in dogBreeds) {
        listop.append('<option value="' + breed + '">' + breed + '</option>');
    }
});
listop.change(function () {
    let type=listop.val();
    let url = "https://dog.ceo/api/breed/" + type + "/list";
    $("#dog-sub-breeds").remove();
    $.get(url, function (data) {
    if(data.message.length!==0){
        let subBreeds = data.message;

             listop.after('<select id="dog-sub-breeds"></select>');

            var subDropdown = $("#dog-sub-breeds");

            for (let subBreed of subBreeds) {
                subDropdown.append('<option value="' + subBreed + '">' + subBreed + '</option>');
                console.log(subBreed);
            }
    }
});
    
});
$('#getbtn').click(function(event){
    event.preventDefault();
        Breed=listop.val();
        subbreed=$("#dog-sub-breeds").val();
        show(Breed,subbreed);
});
function show(Breed,subbreed){
    $("#sec img").remove();
    let url = "https://dog.ceo/api/breed/" + Breed;
    if(subbreed!==undefined){
        url+="/"+subbreed+"/images";
    }else{
        url+="/images";
    }
    $.get(url, function (data) {
    let imgUrl = data.message;
    for(let img of imgUrl){
        $('#sec').append('<img src="' + img + '" alt="' + Breed + '">');
 
    }
    
});
}
