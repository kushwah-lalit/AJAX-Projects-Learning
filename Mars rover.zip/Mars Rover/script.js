var input = $("#datepicker").datepicker({ dateFormat: 'yy-mm-dd' });
$('#getbtn').click(function(event){
    event.preventDefault();
    var date=input.val();
    
    if( date === "") {
        alert("Please fill the field");
        return;
    }
    let url = "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?earth_date=" + date + "&api_key=DEMO_KEY";
    $.get(url, function (data) {
        let photos = data.photos;
        
        if(photos.length === 0 ) {
            alert("No photos available for this date");
            return;
        }
        
        $("#sec img").remove();

        for (let photo of photos) {
            $('#sec').append('<img src="' + photo.img_src + '" alt="' + photo.id + '">');
        }
    });
    
    
});